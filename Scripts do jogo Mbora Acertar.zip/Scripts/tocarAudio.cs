﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tocarAudio : MonoBehaviour {

	public AudioSource tocar;

	// Use this for initialization
	void Start () {

		tocar.Play ();
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
