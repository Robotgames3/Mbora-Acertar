﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Link : MonoBehaviour {

	public void Facebook()
	{
		Application.OpenURL ("https://free.facebook.com/profile.php?ref_component=mfreebasic_home_header&ref_page=MMessagingEntBasedReadController&refid=12");
	}


	public void Google()
	{
		Application.OpenURL ("https://www.elisiorobot3@gmail.com");
	}
}
